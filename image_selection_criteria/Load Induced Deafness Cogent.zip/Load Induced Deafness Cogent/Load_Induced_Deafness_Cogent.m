% Load induced deafness (Exp. 1, 12.10.2012) %%%%
%
%%%%%%% by Kate Molloy (UCL);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Presents a visual search task  of high or low perceptual load, and
% randomly presents a tone on 50% of trials.
%
% Responses: press "0" for X and "2" for Z. (((press "S" for sound present and "A" for sound absent)))
%
% To exit, press Ctrl+C, and then Alt+Tab to switch to matlab command
% window and type 'stop_cogent'
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
clear all
clc

%% Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% display
screenRes = 1;                              % 1=640x480, 2=800x600, 3=1024x768, 4=1152x864, 5=1280x1024, 6=1600x1200
screenSize = [640 480];                     % sprite size required for full display
dpi = 96;                                   % display dpi
viewDist = 57;                              % observer's viewing distance (cm)
screenMode = 1;                             % 0 for window, 1 for full screen
screenCol = [0 0 0];                        % black screen background
screenFont = 'Arial Narrow';                % default font
screenFontSize = 24;                        % default font size

% audio
soundChannels = 1;                          % 1 = mono, 2 = stereo
soundBits = 16;                             % 8 or 16?
soundSampleFreq = 44100;                    % sampling frequency
soundBuffers = 5;                           % number of sound buffers

% task
nBlocks = 8;                                % # blocks - MUST BE EVEN!
nTrials = [3 56];                           % # trials - MUST BE DIVISIBLE BY 8 to counterbalance tones!
blocks = [1 1 1 2*ones(1,nBlocks)];         % 1 = practice, 2 = experimental block

% times
reminderDur = 3000;                         % duration of reminder screen at beginning of each block
fixationDur = 1000;                         % fixation duration (ms)
stimDur = [1000 1000 300*ones(1,nBlocks+1)];% stimulus duration (ms)- visual and auditory
audExDur = 200;                             % duration of example tone
probeDurVis = 1900;                         % visual (primary) response window duration (ms)
probeDurAud = 2000;                         % auditory (sedondary) response window duration (ms)

% visual search array
arraySize = 1.7;                            % size of search display (dva)
nLetters = 10;                               % # of positions in the search array - 10 MAX AT THE MOMENT

% array letters
letterFont = 'Arial Narrow';                % font for search task letters
letterSize = [0.6,0.2];                     % font sizes for search task letters (dva) for high and low load
letterSet = {'X', 1;    %1                  % targets
             'Z', 1;    %2
             'K', 1;    %3                  % high load distractors
             'W', 1;    %4
             'V', 1;    %5
             'N', 1;    %6
             'M', 1;    %7
             'H', 1;    %8
             'L', 1;    %9 
             'T', 1;    %10
             'F', 1;    %11
             'E', 1;    %12
             'O', 2};   %13                  % low load distractor

% tones
toneFrequency = [0 500 1000 1500 2000];    % frequencies of tones for auditory task
toneLevelFactor = 2;                       % scaler for thresholds to give tone levels
toneRamp = 10;                             % ramp duration (ms)

% instruction text
instruction = cell(13,4);
instruction(:,1) = {'MAIN TASK:';...
    '';...
    'You will be presented with six letters arranged in a circle.';...
    'In each display, one of the letters will be either an X or a Z.';...
    'These are your taget letters. Your task is to indicate which of these two';...
    'target letters are present.';...
    '';...
    'Using your right hand,';...
    'If an "X" is present press the "0" key';...
    'if a "Z" is present press the "2" key ';...
    'Respond as fast as you can while also being accurate.';...
    '';...
    'Press the space bar to continue to further instructions...'};
instruction(:,2) = {
    'SECONDARY TASK:';...
    '';...
    'As the letters are displayed, you will occasionally hear a beep.';...
    'To hear an example of the beep, press "S" now.';...
    '';...
    'After you have indicated which target letter was present, you will see';...
    'a prompt asking whether or not there was a sound.';...
    '';...
    'Using your left hand,';...
    'press "S" if there WAS a sound';...
    'press "A" if there WAS NOT a sound';...
    '';...
    ['We' char(39) 'll begin with some slowed down examples, press the space bar to continue.']};
instruction(:,3) = {''; ''; '';...
    'REMEMBER';...
    '';...
    '';...
    'X = 0                              Z = 2';...
    '';...
    '';...
    'Sound = S          No Sound = A';...
    ''; ''; ''};
instruction(:,4) = {''; ''; ''; ...
    'GREAT!';...
    '';...
    'Sometimes the letters in the circle will be harder to tell apart.';...
    ['We' char(39) 'll do some slowed down examples of the harder task now.'];...
    'Your task is the same as before.';...
    '';...
    'Press the space bar to start.'; ''; ''; ''};
instruction(:,5) = {''; ''; '';...
    'GREAT!';...
    '';...
    ['Now that you' char(39) 've seen some slowed down examples, let' char(39) 's try some faster ones.'];...
    ['The tasks are the same as you' char(39) 've just done, but now the speed will be as'];...
    'fast as it is in the actual experiment.';...
    '';...
    'Press the space bar to start.'; ''; ''; ''};
instruction(:,6) = {''; ''; ''; '';'';...
    'You have now completed the practice trials!';...
    '';...
    'Press the space bar to start the main experiment.'; ''; ''; ''; ''; ''};

nInstruct = size(instruction);

toneProbe = 'Did you hear a beep?';

% calculations
pixPerDegree = (viewDist*(tan(1*pi/180)))*dpi/2.54;     % calculate number of pixels per dva
arraySize = round(arraySize*pixPerDegree);              % convert array size from dva to pixels
letterSize = round(letterSize*pixPerDegree);            % convert letter size from dva to pixels
for i=1:nLetters                                        % calculate positions for array elements
    centres(i,1) = arraySize*sin(2*pi*i/nLetters);
    centres(i,2) = arraySize*cos(2*pi*i/nLetters);
end


%% Get Subject Info  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prompt = {'Subject Number:','Subject Initials:','Gender (f/m)','Age'}; %prompt
default = {'1-1-000','XX','fm','0'};
dlgname = 'Setup Info';
LineNo = 1;
answer = inputdlg(prompt,dlgname,LineNo,default);
[subNum, sub, sex, age] = deal(answer{:});

subInfo = [{'Subject Number'},{'Name'},{'Sex'},{'Age'};...
           {subNum},{sub},{sex},{age}];

load(['.\data\' subNum '\thresholds\thresholds']);
       
rand('seed',fix(100*sum(clock)));  %seed the random number generator using the computer clock

%% Start Cogent and prepare sprites

config_display(screenMode, screenRes, screenCol);
config_sound(soundChannels, soundBits, soundSampleFreq, soundBuffers)
config_keyboard;
start_cogent
map = getkeymap;

% prepare instruction sprites - n = 1:6
for i=1:nInstruct(2)
    cgmakesprite(i, screenSize(1), screenSize(2), screenCol);
    cgsetsprite(i);
    cgpencol(1, 1, 1);
    cgfont(screenFont,screenFontSize);
    for j=1:nInstruct(1)
        cgtext(instruction{j,i},0,(nInstruct(1)/2-j)*25);
    end
end

% prepare face sprites
cgmakesprite(8, 150, 150, screenCol);
cgsetsprite(8);
cgloadbmp(8, 'Happy.bmp', 150, 150)

cgmakesprite(9, 150, 150, screenCol);
cgsetsprite(9);
cgloadbmp(9, 'Awesome.bmp', 150, 150)

% prepare fixation cross - n = 10
cgmakesprite(10, screenSize(1), screenSize(2), screenCol);
cgsetsprite(10);
cgpencol(1, 1, 1);
cgdraw(-8,0,8,0);
cgdraw(0,-8,0,8);

% prepare blank screen n = 11
cgmakesprite(11, screenSize(1), screenSize(2), screenCol);
cgsetsprite(11);
cgpencol(1, 1, 1);

% prepare tone probe screen = n = 12
cgmakesprite(12, screenSize(1), screenSize(2), screenCol);
cgsetsprite(12);
cgpencol(1, 1, 1);
cgfont(screenFont,screenFontSize);
cgtext(toneProbe,0,0);

% prepare letter sprites - n = 20:28
for i=20:19+length(letterSet)
    cgmakesprite(i, 25, 25, [0 0 0]);
    cgsetsprite(i);
    cgpencol(1, 1, 1);
    cgfont(letterFont,letterSize(letterSet{i-19,2}));
    cgtext(letterSet{i-19,1},0,0);
end

% load example tones into sound buffers
toneLevel = thresholds*toneLevelFactor; % scale thresholds so they're a set number of dB above threshold

for i=1:length(toneFrequency)
    x = linspace(0, audExDur/1000,soundSampleFreq*audExDur/1000)';
    x = toneLevel(i) * sin(2*pi*toneFrequency(i) * x);
    y = linspace(0, 1000/(toneRamp*soundSampleFreq), toneRamp*soundSampleFreq/1000);
    ramp  = ones(size(x));
    ramp(1:length(y)) = ((1+(cos(2*pi*(length(y)/2)*y + pi)))/2).^2;
    ramp((end-length(y)+1):end) = ((1+(cos(2*pi*(length(y)/2)*y )))/2).^2;
    x = x .* ramp;
    preparesound(x,i);
end

%% Experiment

% set load for each block
load = [1 2 2 Shuffle([ones(1,nBlocks/2) 2*ones(1,nBlocks/2)])];

% display initial instrctions
for i=1:2
    cgsetsprite(0)
    cgdrawsprite(i,0,0)
    cgflip;
        
    % wait for space or S to play sound
    if i==2 
      done = 0;  
        while done == 0
            [key, time, n] = waitkeydown(inf,[map.Space map.S]);
            if key == 19
                playsound(2)
            else
                done = 1;
            end
        end
    else
        waitkeydown(inf,map.Space)
    end

end

% block loop
for b=1:length(blocks)
        
    % randomise auditory and visual targets for trials
    if blocks(b)==1
        targetLetter = Shuffle([1 1 2]);
        targetTone = Shuffle([1 1 3]);
    else
        targetLetter = Shuffle([ones(1,nTrials(blocks(b))/2) 2*ones(1,nTrials(blocks(b))/2)]);
        targetTone = Shuffle([repmat(2:5,1,nTrials(blocks(b))/8) 1*ones(1,nTrials(blocks(b))/2)]);
    end
    
    % set up data arrays
    data = cell(nTrials(blocks(b))+ 2,12);
    data(1,:) = {'Block', b, 'Load', load(b), '', '', '', '', '', '', '', ''};
    data(2,:) = {'VisTarget', 'VisResp', 'VisRT', 'AudTarget', 'AudResp',...
        'AudRT', 'Fixation', 'Array', 'Blank', 'VisResp', 'AudProbe', 'AudResp'};

    % create savefile
    save(['.\data\' subNum '\' subNum '_' num2str(b)], 'data', 'subInfo')
    
    % load tones into sound buffers
    x = linspace(0, stimDur(b)/1000,soundSampleFreq*stimDur(b)/1000)';
    x = repmat(x,1,length(toneFrequency));
    y = linspace(0, 1000/(toneRamp*soundSampleFreq), toneRamp*soundSampleFreq/1000);
    ramp  = ones(length(x),1);
    ramp(1:length(y)) = ((1+(cos(2*pi*(length(y)/2)*y + pi)))/2).^2;
    ramp((end-length(y)+1):end) = ((1+(cos(2*pi*(length(y)/2)*y )))/2).^2;
    for i=1:length(toneFrequency)
        x(:,i) = toneLevel(i) * sin(2*pi*toneFrequency(i) .* x(:,i));
        x(:,i) = x(:,i) .* ramp;
        preparesound(x(:,i),i);
    end
    
    % display reminder screen
    cgsetsprite(0)
    cgdrawsprite(3,0,0)
    cgflip;
    wait(2000)
    
    % trial loop
    for t=1:nTrials(blocks(b))
        % shuffle letter positions
        if load(b) == 1
            letters = Shuffle([targetLetter(t) 13*ones(1,nLetters-1)]);
        elseif load(b) == 2
            letters = Shuffle([targetLetter(t) 3:(nLetters+2)]);
        else
            Error('Error from line 186: Load not set!')
        end
        
        % create array sprite
        cgmakesprite(100+t, screenSize(1), screenSize(2), [0 0 0]);
        cgsetsprite(100+t);
        for i=1:nLetters
            cgdrawsprite(19+letters(i),centres(i,1),centres(i,2));
        end
        
        % load and display fixation cross on first trial
        if t==1
            cgsetsprite(0)
            cgdrawsprite(10,0,0)
            data{t+2,7} = cgflip;
        else
        end
        
        % load and display array and sound
        cgsetsprite(0)
        cgdrawsprite(100+t,0,0)
        waituntil(fixationDur + data{t+2,7}*1000)
        data{t+2,8} = cgflip;
        clearkeys;
        playsound(targetTone(t))
        
        % load and display blank screen
        cgsetsprite(0)
        cgdrawsprite(11,0,0)
        waituntil(stimDur(b) + data{t+2,8}*1000)
        data{t+2,9} = cgflip;
        
        % load tone probe screen
        cgsetsprite(0)
        cgdrawsprite(12,0,0)
        
        % log visual response
        waituntil(probeDurVis + data{t+2,9}*1000)
        readkeys;
        [key, time, n] = getkeydown;
        if n == 1                                   % single key press
            data{t+2,2} = key(1);                  % response key
            data{t+2,10} = time(1)/1000;                % time of response (s)
        else                                        % no or multiple key press
            data{t+2,2} = NaN;                     % no response key
            data{t+2,10} = NaN;                         % no time of response
        end
        
        % display auditory probe screen and log response
        data{t+2,11} = cgflip;
        clearkeys;
        [key, time, n] = waitkeydown(probeDurAud,[map.A map.S]);
        
        if n == 1                                   % single key press
            data{t+2,5} = key(1);                  % response key
            data{t+2,12} = time(1)/1000;                % time of response (s)
        else                                        % no or multiple key press
            data{t+2,5} = NaN;                     % no response key
            data{t+2,12} = NaN;                         % no time of response
        end
        
        % finish logging data
        data{t+2,1} = targetLetter(t);                 % vis target
        data{t+2,3} = data{t+2,10} - data{t+2,8};      % RT for vis resp
        data{t+2,4} = targetTone(t);                   % aud target
        data{t+2,6} = data{t+2,12} - data{t+2,11};     % RT for aud resp
        
        % prepare blank screen and display
        cgsetsprite(0)
        cgdrawsprite(11,0,0)
        cgflip;
        
        % save data
        save(['.\data\' subNum '\' subNum '_' num2str(b)], 'data', '-append')
     
        % prepare and display fixation cross for next trial, unless final trial
        if t == nTrials(blocks(b))
            waituntil(probeDurAud + data{t+2,11}*1000)
        else
            cgsetsprite(0)
            cgdrawsprite(10,0,0)
            waituntil(probeDurAud + data{t+2,11}*1000)
            data{t+3,7} = cgflip;
        end
    end
    
    % display screen to introduce next block/end
    cgsetsprite(0)
    cgfont(screenFont,screenFontSize);
    if b == length(blocks)
        finalText = {
            'Finished!!!';...
            '';...
            '';...
            ''; ''; ''; ''; ''; ''; ''; ''; ''; ...
            'Press the space bar to exit.'};
        cgdrawsprite(11,0,0)
        cgpencol(1, 1, 1);
        for j=1:length(finalText)
            cgtext(finalText{j},0,(length(finalText)/2-j)*25);
        end
        cgdrawsprite(9,0,0)
    elseif b==1 || b==2 || b==3
        cgdrawsprite(b+3,0,0)
    else
        text = {
            'Well done!';...
            '';...
            ['Block ' num2str(b-3) ' of ' num2str(nBlocks) ' completed.'];...
            ''; ''; ''; ''; ''; ''; ''; ''; ''; ...
            'Press the space bar to start the next block.'};
        cgdrawsprite(11,0,0)
        cgpencol(1, 1, 1);
        for j=1:length(text)
            cgtext(text{j},0,(length(text)/2-j)*25);
        end
        cgdrawsprite(8,0,-40)
    end
    cgflip;
    waitkeydown(inf,[map.Space])
    
    % save final data
    save(['.\data\' subNum '\' subNum '_' num2str(b)], 'data', '-append');
    dlmcell(['.\data\' subNum '\' subNum '_' num2str(b) '.csv'], data,',');
    
end
dlmcell(['.\data\' subNum '\' subNum '_subjectInfo.csv'],subInfo,',');
stop_cogent
